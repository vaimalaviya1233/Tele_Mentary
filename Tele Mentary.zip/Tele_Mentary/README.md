# Tele_Mentary

Protector Of Energy

project requires minimum api level of Android 30 (Android 11/R)
on other api level or other android version thus might not work as intended

this app allows to disable app(SYNCHRONOUS)/enable app and uninstall app disabling/ enabling app
works mostly on Android 11(R)
Uninstalling app will work on most of the android versions no later than android api level 28(Oreo)

disabling apps through admin will be great idea. but it is in work ,and android 9,10,11,12 made
significant changes to device admin and dpm apis.

